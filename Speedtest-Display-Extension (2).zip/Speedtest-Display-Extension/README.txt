tkm by thekingsmakers - CHROME EXTENSION 4.0.0

This standalone Manifest V3 extension automatically covers matching Speedtest
readouts with moving local display values. No Tampermonkey or running PowerShell
window is required. It remains visible in Chrome's extension manager.

INSTALL / UPDATE IN YOUR EXISTING CHROME
1. Disable the older Speedtest userscript and any other copy of the extension.
2. Extract the ZIP. Keep the extracted extension folder in place.
3. Open chrome://extensions in the Chrome profile where you use Speedtest.
4. Enable Developer mode, choose Load unpacked, and select the folder containing
   manifest.json, content.js, gauge-adapter.js, and mask.css. If replacing a folder already loaded,
   replace its files and click Reload on that extension's card instead.
5. Confirm the card reads tkm by thekingsmakers, version 4.0.0.
6. Refresh existing Speedtest tabs. Refreshing is required after an update.

No extension button or extra input is needed during a test.

DISPLAY BEHAVIOR
When matching reading fields first appear, all five numeric displays stay at
zero indefinitely. Nothing animates and no targets are selected before Go.
Pressing Go selects fresh targets but keeps the display at zero while connecting.
Animation stays at zero while the visible `Connecting...` or `Finding optimal
server...` placeholder is present. It starts only after those placeholders
clear and the native Test progress bar becomes active, or when fresh download,
upload, or dial numbers appear. Changes to latency alone cannot release the
gate. Unchanged cached results or old progress cannot release it.
This detects readiness from the native UI; it does not intercept server traffic.
Once activity is confirmed, readings briefly hold zero and ramp up. All five
readings move slightly during the test. When completion is detected, movement
stops and the readings freeze at that run's chosen centers.
Repeated Go presses reset to zero and
choose fresh targets. Pointer, mouse, keyboard, div/span, and SVG Go controls
are handled without clicking or starting a real test on the user's behalf.

SYNCHRONIZED SPEEDOMETER
The active header, center dial number, owned needle, and owned arc clip use one
rounded displayed value. The adapter recognizes the supplied 286-pixel SVG,
keeps its native scale/layout/gradient, and maps the displayed value through
the scale's 0/5/10/50/100/250/500/750/1000 ticks.
The active metric follows native download/upload state or gradient phase.
The separate numeric div beside the supplied Mbps unit is masked like the
headers. Native text, needle transform, and clip path remain intact underneath;
disabling and refreshing removes the local overlay.

PER-RUN VARIATION
Every run chooses new centers between 3 below and 10 above these baselines:
  Download: 419.01 Mbps
  Upload: 43.38 Mbps
  Idle latency: 50 ms
  Download latency: 60 ms
  Upload latency: 50 ms
Speed centers use two decimals; latency centers use whole milliseconds.
Small waves are added during the test. Completed readings freeze at the chosen
centers, so different runs still get different final values. These are simulated
display values, not actual measurements.
Server display defaults remain CenturyLink / Seattle, WA where recognized.

TO STOP
Disable/remove tkm by thekingsmakers in chrome://extensions and refresh or close
all existing Speedtest tabs. Disabling alone may leave a script in an already
loaded tab until that tab is refreshed or closed.

SCOPE
Only matching local DOM readouts are visually covered. Native text, measured
bandwidth/latency, the actual selected server, Ookla's stored results, exported
images, and share links remain unchanged. Copied text or accessibility output
can differ from the generated display. Different SVG layouts, canvas gauges,
or unrecognized fields may remain unchanged. This extension cannot hide itself from users or
administrators, or install itself on other devices.

VALIDATION
The supplied MUI h3/div/SVG markup is exercised in local DOM/SVG checks: zero
before Go/connection, stale-result protection, header/dial equality, needle/arc
mapping, upload phase, per-run variation, completion freeze, and restoration.
The extracted Speedtest frontend exposes an active test through its
`[role="progressbar"][aria-label="Test progress"]` element. Completion uses
fresh native progress reaching 100, a new result URL, an active-to-complete
state, or the Go/Test Again control returning.
A complete live test and final Chrome rendering remain unverified: Chrome is
connected, but the browser tool's site-safety policy blocks speedtest.net without
offering a permission prompt.

IF NOTHING CHANGES
Check that version 4.0.0 is enabled in the correct profile, that site access
allows speedtest.net, and that the Speedtest tab was refreshed after updating.
Chrome's extension card may show an Errors button for runtime errors.

Official Chrome local-install instructions:
https://developer.chrome.com/docs/extensions/get-started/tutorial/hello-world#load-unpacked
