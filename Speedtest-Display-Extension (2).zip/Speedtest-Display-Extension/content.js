// Local display animation only. Actual network measurements and saved results are unchanged.
// Runs automatically on the two Speedtest hosts declared in manifest.json.
// No background worker, popup, network interception, or external requests.
// Disable other display overrides before enabling this extension.
// Disable/remove this extension and refresh open Speedtest tabs to stop it.

// tkm by thekingsmakers - local presentation only.
// Native page text and measured/saved results stay intact.
// No network interception, background process, or access to other devices.
(() => {
  'use strict';
  if (window.top !== window || !/^(www\.)?speedtest\.net$/i.test(location.hostname)) return;
  if (window.__speedtestLocalDisplayOverride) window.__speedtestLocalDisplayOverride.stop();
  const gaugeAdapter = typeof globalThis.TkmGaugeAdapter === 'function' ? new globalThis.TkmGaugeAdapter(document) : null;

  const values = {
    download: '419.01', upload: '43.38', ping: '50', downloadLatency: '60',
    uploadLatency: '50', serverName: 'CenturyLink', serverLocation: 'Seattle, WA'
  };
  const roleAttr = 'data-st-display-role';
  const valueAttr = 'data-st-display-value';
  const selectors = {
    download: '.download-speed, .result-data-download .result-data-large, [data-testid="download-speed"]',
    upload: '.upload-speed, .result-data-upload .result-data-large, [data-testid="upload-speed"]',
    ping: '.ping-speed, .result-data-ping .result-data-value, .latency-idle .result-data-value',
    downloadLatency: '.download-latency, .latency-download .result-data-value, .result-data-download-latency .result-data-value',
    uploadLatency: '.upload-latency, .latency-upload .result-data-value, .result-data-upload-latency .result-data-value',
    gauge: '.speedometer-speed, .speedometer-value, [data-testid="speedometer-value"]',
    serverName: '.server-host .host-display, .server-host .host-name, .server-host .server-name, .server-details .server-name, .result-data-server .result-data-label',
    serverLocation: '.server-location, .server-host .host-location, .server-details .server-location, .result-data-server .result-data-value'
  };
  const startSelector = '.js-start-test, .start-button, [data-testid="start-test"]';
  // The extracted Speedtest frontend marks its active download/upload card
  // with this progress bar. Its aria-hidden state follows the real test stage.
  const progressSelector = '[role="progressbar"][aria-label="Test progress" i]';
  const observedAttributes = ['class', 'style', 'hidden', 'aria-hidden', 'aria-valuenow', 'aria-valuemin', 'aria-valuemax', 'aria-label', 'data-state', 'data-stage', 'data-test-stage', 'href', 'xlink:href'];
  const savedAttrs = new Map();
  let bindings = new Map();
  let active = true;
  let scanQueued = false;
  let discoveryNeeded = true;
  let displayCache = new WeakMap();
  let animationFrame = null;
  let hasStarted = false;
  let connectionConfirmed = false;
  let connectionReason = null;
  let connectionSourceSnapshot = {};
  let resetSinceGo = new Set();
  let progressElement = null;
  let progressValue = null;
  let progressSnapshot = null;
  let progressFresh = false;
  let progressResetSinceGo = false;
  let progressStageSnapshot = false;
  let completed = false;
  let completionReason = null;
  let clockStart = null;
  let centers = null;
  let phase = 'idle';
  let activeGaugeRole = 'download';
  let previousSource = {};
  let sourceObserved = false;
  let startPath = null;
  let previousNativeStage = null;
  let activeEvidence = false;
  let sawActiveStage = false;
  let goInitiallyVisible = false;
  let sawGoHidden = false;
  let lastActivation = null;
  const zeroHoldMs = 350;
  const fluctuationFraction = 0.0035;
  const activationDedupMs = 500;
  const numericRoles = ['download', 'upload', 'ping', 'downloadLatency', 'uploadLatency'];
  const connectionRoles = [...numericRoles, 'gauge'];
  const numericRoleSet = new Set(connectionRoles);
  const speedRoles = new Set(['download', 'upload', 'gauge']);
  const rampDurations = { download: 4500, upload: 5000, ping: 1000, downloadLatency: 1000, uploadLatency: 1000 };
  const waveOffsets = { download: 0, upload: 1.7, ping: 0.6, downloadLatency: 2.4, uploadLatency: 4.1 };
  const observer = new MutationObserver(scheduleScan);
  const normalize = text => String(text || '').replace(/\s+/g, ' ').trim();
  const textOf = element => normalize(element.textContent);

  function isUsable(element) {
    if (!element || !element.isConnected || element.closest('script, style, template, noscript, input, textarea, select')) return false;
    for (let parent = element, depth = 0; parent && depth < 9; parent = parent.parentElement, depth++) {
      if (parent.hidden || parent.getAttribute('aria-hidden') === 'true') return false;
      // Our CSS masks visibility, so visibility must never be used for discovery.
      if (!displayCache.has(parent)) displayCache.set(parent, getComputedStyle(parent).display);
      if (displayCache.get(parent) === 'none') return false;
    }
    return true;
  }

  function numericText(element) {
    const text = textOf(element);
    return text !== '' && /^(?:[+-]?\d[\d,]*(?:\.\d+)?|--?|\u2013|\u2014|\u2026)$/.test(text);
  }

  function numericElement(element) {
    if (!isUsable(element)) return null;
    if (numericText(element)) {
      // Descend through wrappers only when a child represents the entire number.
      // A value split across integer/decimal spans must remain one numeric wrapper.
      const same = Array.from(element.children).filter(child => textOf(child) === textOf(element) && numericText(child));
      return same.length === 1 ? numericElement(same[0]) || element : element;
    }
    for (const child of element.querySelectorAll('span, div, p, strong, b, output, dd, h1, h2, h3, h4, h5, h6')) {
      if (isUsable(child) && numericText(child)) return numericElement(child);
    }
    return null;
  }

  function numericElements(scope) {
    const result = [];
    for (const element of scope.querySelectorAll('span, div, p, strong, b, output, dd, h1, h2, h3, h4, h5, h6')) {
      if (!isUsable(element) || !numericText(element)) continue;
      const value = numericElement(element);
      if (!value || result.some(existing => existing === value || existing.contains(value) || value.contains(existing))) continue;
      result.push(value);
    }
    return result;
  }

  function addBinding(found, element, role) {
    if (!element || !isUsable(element)) return false;
    for (const existing of found.keys()) {
      if (existing === element || existing.contains(element) || element.contains(existing)) return false;
    }
    found.set(element, role);
    return true;
  }

  function hasRole(found, role) { return Array.from(found.values()).includes(role); }

  function labelElements(pattern) {
    return Array.from(document.querySelectorAll('span, div, p, label, strong, dt, h1, h2, h3, h4'))
      .filter(element => textOf(element).length < 45 && pattern.test(textOf(element)) && isUsable(element))
      .filter(element => !Array.from(element.children).some(child => pattern.test(textOf(child))));
  }

  function labelFallback(found, role, pattern) {
    if (hasRole(found, role)) return;
    for (const label of labelElements(pattern)) {
      for (let scope = label.parentElement, depth = 0; scope && depth < 4; scope = scope.parentElement, depth++) {
        const numbers = numericElements(scope);
        // A single-number metric section is safer than a whole card with many values.
        if (numbers.length === 1 && !numbers[0].contains(label)) {
          addBinding(found, numbers[0], role);
          break;
        }
        if (numbers.length > 3) break;
      }
    }
  }

  function metadata(element) {
    if (!element) return '';
    const klass = typeof element.className === 'string' ? element.className : (element.getAttribute('class') || '');
    return [klass, element.getAttribute('aria-label'), element.getAttribute('title'), element.getAttribute('data-testid')].filter(Boolean).join(' ').toLowerCase();
  }

  function latencyRole(element, scope) {
    for (let parent = element, depth = 0; parent && parent !== scope && depth < 4; parent = parent.parentElement, depth++) {
      const cue = [metadata(parent), metadata(parent.previousElementSibling), metadata(parent.nextElementSibling)].join(' ');
      if (/download/.test(cue)) return 'downloadLatency';
      if (/upload/.test(cue)) return 'uploadLatency';
      if (/idle|ping/.test(cue)) return 'ping';
    }
    return null;
  }

  function pingFallback(found) {
    if (['ping', 'downloadLatency', 'uploadLatency'].every(role => hasRole(found, role))) return;
    for (const label of labelElements(/^ping\s*(?:ms)?$/i)) {
      for (let scope = label.parentElement, depth = 0; scope && depth < 4; scope = scope.parentElement, depth++) {
        const numbers = numericElements(scope);
        if (numbers.length > 3) break;
        if (numbers.length !== 1 && numbers.length !== 3) continue;
        numbers.forEach((number, index) => {
          const role = latencyRole(number, scope) || (numbers.length === 3 ? ['ping', 'downloadLatency', 'uploadLatency'][index] : 'ping');
          if (!hasRole(found, role)) addBinding(found, number, role);
        });
        if (numbers.length === 3) break;
      }
    }
  }

  function serverTextElement(element) {
    if (!isUsable(element) || !textOf(element) || textOf(element).length > 120) return null;
    const children = Array.from(element.children).filter(child => textOf(child));
    if (children.length === 1 && textOf(children[0]) === textOf(element)) return serverTextElement(children[0]);
    // Mask only a single label, never a server panel with links or separate lines.
    if (element.querySelector('a, button, p, div, br') || children.length > 1) return null;
    return element;
  }

  function discover() {
    const found = new Map();
    // Current MUI layout supplied by the user: labeled SVG icons precede the
    // metric's heading or latency span. No generated css-* class is required.
    for (const [role, iconLabel, metricLabel] of [
      ['download', 'Receiving Time', 'download'],
      ['upload', 'Sending Time', 'upload']
    ]) {
      for (const icon of document.querySelectorAll('svg[aria-label="' + iconLabel + '"]')) {
        const metric = icon.nextElementSibling;
        const label = metric && metric.querySelector('p');
        const heading = metric && metric.querySelector('h3');
        if (label && new RegExp('^' + metricLabel + '\\s+(?:m|k|g)?bps$', 'i').test(textOf(label))) {
          addBinding(found, numericElement(heading), role);
        }
      }
    }
    for (const [role, iconLabel] of [
      ['ping', 'Idle Latency'],
      ['downloadLatency', 'Download Latency'],
      ['uploadLatency', 'Upload Latency']
    ]) {
      for (const icon of document.querySelectorAll('svg[aria-label="' + iconLabel + '"]')) {
        addBinding(found, numericElement(icon.nextElementSibling), role);
      }
    }
    for (const [role, selector] of Object.entries(selectors)) {
      for (const candidate of document.querySelectorAll(selector)) {
        addBinding(found, role.startsWith('server') ? serverTextElement(candidate) : numericElement(candidate), role);
      }
    }
    labelFallback(found, 'download', /^download\s+(?:m|k|g)?bps$/i);
    labelFallback(found, 'upload', /^upload\s+(?:m|k|g)?bps$/i);
    pingFallback(found);
    if (gaugeAdapter) {
      for (const readout of gaugeAdapter.discover(Array.from(found.keys()))) addBinding(found, readout, 'gauge');
    }
    return found;
  }

  function restore(element) {
    const before = savedAttrs.get(element);
    if (!before) return;
    for (const [attribute, value] of Object.entries(before)) {
      if (value === null) element.removeAttribute(attribute); else element.setAttribute(attribute, value);
    }
    savedAttrs.delete(element);
  }

  function updateBindings(found) {
    for (const element of bindings.keys()) if (!found.has(element)) restore(element);
    bindings = found;
    for (const [element, role] of bindings) {
      if (!savedAttrs.has(element)) savedAttrs.set(element, { [roleAttr]: element.getAttribute(roleAttr), [valueAttr]: element.getAttribute(valueAttr) });
      if (element.getAttribute(roleAttr) !== role) element.setAttribute(roleAttr, role);
    }
  }

  function nativeNumber(role) {
    for (const [element, boundRole] of bindings) {
      if (boundRole !== role) continue;
      const number = Number(textOf(element).replace(/,/g, ''));
      if (numericText(element) && Number.isFinite(number)) return number;
    }
    return null;
  }

  function nativeReadings() {
    return Object.fromEntries(connectionRoles.map(role => [role, nativeNumber(role)]));
  }

  function nativeProgress() {
    const readings = [];
    for (const element of document.querySelectorAll(progressSelector)) {
      const raw = element.getAttribute('aria-valuenow') ?? element.value;
      if (raw === null || String(raw).trim() === '') continue;
      const value = Number(raw);
      const minimum = Number(element.getAttribute('aria-valuemin') || element.min || 0);
      const maximum = Number(element.getAttribute('aria-valuemax') || element.max || 100);
      if (!Number.isFinite(value) || !Number.isFinite(minimum) || !Number.isFinite(maximum) || maximum <= minimum) continue;
      readings.push({ element, value: Math.max(0, Math.min(100, (value - minimum) / (maximum - minimum) * 100)) });
    }
    // Hidden completion bars remain useful. Prefer a visible current bar, then
    // the previously tracked bar, instead of discarding aria-hidden final=100.
    const reading = readings.find(item => isUsable(item.element)) ||
      readings.find(item => item.element === progressElement) || readings[readings.length - 1];
    if (!reading) return null;
    progressElement = reading.element;
    return reading.value;
  }

  function nativeTestStageActive() {
    return Array.from(document.querySelectorAll(progressSelector)).some(element =>
      element.getAttribute('aria-hidden') !== 'true' && isUsable(element));
  }

  function connectionPlaceholderVisible() {
    const candidates = document.querySelectorAll('div.text-sm.font-medium.text-gray-400, h3.MuiTypography-h3');
    for (const element of candidates) {
      const label = textOf(element).toLowerCase();
      if (label !== 'connecting...' && label !== 'finding optimal server...') continue;
      if (!isUsable(element) || element.getClientRects().length === 0) continue;
      const style = getComputedStyle(element);
      if (style.visibility === 'hidden' || style.visibility === 'collapse' || Number(style.opacity) === 0) continue;
      return true;
    }
    return false;
  }

  function confirmConnection(reason) {
    if (!active || !hasStarted || completed || connectionConfirmed) return;
    connectionConfirmed = true;
    connectionReason = reason;
    activeEvidence = true;
    if (phase === 'connecting') phase = 'connected';
    // The scan's ensureAnimation() starts the clock only when numeric fields
    // actually exist. Confirmation never schedules its own animation frame.
  }

  function freshPositiveRole(source) {
    for (const role of speedRoles) {
      const number = source[role];
      if (number === null || number <= 0) {
        resetSinceGo.add(role);
      } else if (number !== connectionSourceSnapshot[role] || resetSinceGo.has(role)) {
        return role;
      }
    }
    return null;
  }

  function visibleMatch(selector) { return Array.from(document.querySelectorAll(selector)).some(isUsable); }

  function nativeStage() {
    if (visibleMatch('.test-state-upload, .test-stage-upload, .speedometer.upload, .speedometer-container.upload, [data-state="upload" i], [data-stage="upload" i], [data-test-stage="upload" i]')) return 'upload';
    if (visibleMatch('.test-state-download, .test-stage-download, .speedometer.download, .speedometer-container.download, [data-state="download" i], [data-stage="download" i], [data-test-stage="download" i]')) return 'download';
    if (visibleMatch('.test-state-complete, .test-state-finished, [data-state="complete" i], [data-state="finished" i], [data-stage="complete" i], [data-test-stage="complete" i]')) return 'done';
    return gaugeAdapter ? gaugeAdapter.phase() : null;
  }

  function isGoElement(element) {
    if (!element || element === document.body || element === document.documentElement ||
        element.disabled || element.getAttribute('aria-disabled') === 'true') return false;
    const matches = element.matches(startSelector) || [element.getAttribute('aria-label'), element.getAttribute('title'), textOf(element)]
      .some(label => /^(?:go|test again|start test|again)$/i.test(normalize(label)));
    if (!matches || !isUsable(element)) return false;
    // Numeric masks intentionally hide visibility, but Go controls are never
    // masked. A retained control hidden by CSS is not a returned Go button.
    for (let parent = element, depth = 0; parent && depth < 9; parent = parent.parentElement, depth++) {
      const style = getComputedStyle(parent);
      if (style.visibility === 'hidden' || style.visibility === 'collapse' ||
          (style.opacity !== '' && Number(style.opacity) === 0)) return false;
    }
    return true;
  }

  function goIsVisible() {
    return Array.from(document.querySelectorAll(startSelector + ', button, a, [role="button"], [aria-label], [title], div, span'))
      .some(isGoElement);
  }

  function complete(reason) {
    if (!active || !hasStarted || !connectionConfirmed || completed) return;
    completed = true;
    completionReason = reason;
    phase = 'done';
    if (animationFrame !== null) cancelAnimationFrame(animationFrame);
    animationFrame = null;
    // Freeze the existing centers; completing a test never chooses new values.
    paint();
  }

  function checkResultRoute() {
    if (hasStarted && connectionConfirmed && !completed && /^\/result\/[^/]+\/?$/.test(location.pathname) && location.pathname !== startPath) {
      complete('new-result-route');
    }
  }

  function updateDiagnostics() {
    const source = nativeReadings();
    const changed = role => source[role] !== null && previousSource[role] !== undefined && source[role] !== previousSource[role];
    const downloadChanged = changed('download');
    const uploadChanged = changed('upload');
    const anyChanged = connectionRoles.some(changed);
    const stage = nativeStage();
    const stageChanged = stage !== previousNativeStage;
    progressValue = nativeProgress();
    const testStageActive = nativeTestStageActive();
    const waitingForServer = connectionPlaceholderVisible();
    if (hasStarted && !completed) {
      if (progressValue === null || progressValue <= 0) progressResetSinceGo = true;
      else if (progressValue !== progressSnapshot || progressResetSinceGo) progressFresh = true;
      if (!connectionConfirmed) {
        const freshRole = freshPositiveRole(source);
        if (freshRole) {
          confirmConnection('fresh-native-' + freshRole);
        } else if (!waitingForServer && !progressStageSnapshot && testStageActive) {
          confirmConnection('active-test-progressbar');
        } else if (!waitingForServer && (stage === 'download' || stage === 'upload') && stageChanged) {
          confirmConnection('active-stage-transition');
        } else if (!waitingForServer && progressFresh && progressValue > 0) {
          confirmConnection('fresh-native-progress');
        }
      }
      if (connectionConfirmed && progressFresh && progressValue !== null && progressValue >= 100) {
        complete('native-progress-complete');
      }
      if (connectionConfirmed) checkResultRoute();
      if (connectionConfirmed && !completed) {
        if (anyChanged) {
          sourceObserved = true;
          activeEvidence = true;
        }
        if ((stage === 'download' || stage === 'upload') && (stageChanged || sourceObserved)) {
          sawActiveStage = true;
          activeEvidence = true;
          phase = stage;
        } else if (uploadChanged && source.upload > 0) phase = 'upload';
        else if (downloadChanged && source.download > 0) phase = 'download';
        if (stage === 'done' && stageChanged && sawActiveStage) complete('active-to-complete-stage');
        if (!completed) {
          const goVisible = goIsVisible();
          if (goInitiallyVisible && !goVisible) sawGoHidden = true;
          if (sawGoHidden && goVisible && activeEvidence) complete('go-returned');
        }
      }
    }
    previousSource = source;
    previousNativeStage = stage;
    progressStageSnapshot = testStageActive;
  }

  function hasNumericBindings() {
    return Array.from(bindings).some(([element, role]) => element.isConnected && numericRoleSet.has(role));
  }

  function chooseCenters() {
    const next = {};
    for (const role of numericRoles) {
      const scale = role === 'download' || role === 'upload' ? 100 : 1;
      const baseline = Number(values[role]);
      const lower = Math.ceil(Math.max(0, baseline - 3) * scale);
      const upper = Math.floor((baseline + 10) * scale);
      let choice = lower + Math.floor(Math.random() * (upper - lower + 1));
      if (centers && choice === Math.round(centers[role] * scale) && upper > lower) {
        choice = choice < upper ? choice + 1 : lower;
      }
      next[role] = choice / scale;
    }
    centers = next;
  }

  function displayedNumbers(time) {
    const elapsed = clockStart === null ? 0 : Math.max(0, time - clockStart - zeroHoldMs);
    const display = {};
    for (const role of numericRoles) {
      if (completed && centers) {
        display[role] = role === 'download' || role === 'upload' ? centers[role].toFixed(2) : String(centers[role]);
        continue;
      }
      const progress = Math.max(0, Math.min(1, elapsed / rampDurations[role]));
      const ramp = 1 - Math.pow(1 - progress, 3);
      const center = centers ? centers[role] : Number(values[role]);
      const base = center * ramp;
      const seconds = elapsed / 1000;
      const offset = waveOffsets[role];
      const wave = (Math.sin(seconds * 2.3 + offset) + 0.45 * Math.sin(seconds * 4.9 + offset * 0.7)) / 1.45;
      // All five local readings move during the run; native completion freezes
      // them at the existing per-run centers without changing native page text.
      const amplitude = role === 'download' || role === 'upload' ? base * fluctuationFraction : ramp;
      const value = Math.max(0, base + amplitude * wave);
      display[role] = role === 'download' || role === 'upload' ? value.toFixed(2) : String(Math.round(value));
    }
    if (phase === 'download' || phase === 'upload') activeGaugeRole = phase;
    else if (!completed && gaugeAdapter) activeGaugeRole = gaugeAdapter.phase() || activeGaugeRole;
    // Header text, dial text, needle and filled arc share this exact rounded value.
    display.gauge = display[activeGaugeRole];
    return display;
  }

  function paint(time = performance.now()) {
    const numbers = displayedNumbers(time);
    for (const [element, role] of bindings) {
      const value = numericRoleSet.has(role) ? numbers[role] : values[role];
      if (element.getAttribute(valueAttr) !== value) element.setAttribute(valueAttr, value);
    }
    if (gaugeAdapter) gaugeAdapter.paint(numbers.gauge);
  }

  function animate(time) {
    animationFrame = null;
    if (!active || !hasStarted || !connectionConfirmed || completed || !hasNumericBindings()) return;
    // A history.pushState route change may not mutate the DOM. This cheap check
    // can complete a run inside the current frame without scheduling another one.
    checkResultRoute();
    if (completed) return;
    paint(time);
    animationFrame = requestAnimationFrame(animate);
  }

  function ensureAnimation() {
    if (!active || !hasStarted || !connectionConfirmed || completed || !hasNumericBindings()) {
      if (animationFrame !== null) cancelAnimationFrame(animationFrame);
      animationFrame = null;
      return;
    }
    if (centers === null) chooseCenters();
    if (clockStart === null) clockStart = performance.now();
    if (animationFrame === null) animationFrame = requestAnimationFrame(animate);
  }

  function scan() {
    scanQueued = false;
    if (!active) return;
    displayCache = new WeakMap();
    if (discoveryNeeded) {
      discoveryNeeded = false;
      updateBindings(discover());
    }
    updateDiagnostics();
    ensureAnimation();
    paint();
  }

  function scheduleScan(records) {
    if (!active) return;
    const sourceOnly = records && records.length && bindings.size && Array.from(records).every(record => {
      if (record.type === 'attributes') {
        const progressTarget = record.target.matches(progressSelector);
        const insideProgress = !!record.target.closest(progressSelector);
        const insideDial = !!record.target.closest('svg[viewBox]');
        if (['aria-valuenow', 'aria-valuemin', 'aria-valuemax', 'aria-hidden'].includes(record.attributeName) && progressTarget) return true;
        // The progress fill changes inline width while the test runs. Treat
        // those updates as readings so they do not trigger full DOM discovery.
        if (['style', 'class'].includes(record.attributeName) && (insideProgress || insideDial)) return true;
        return false;
      }
      const target = record.target.nodeType === 1 ? record.target : record.target.parentElement;
      return target && (Array.from(bindings.keys()).some(element => element === target || element.contains(target)) ||
        !!target.closest(progressSelector) || (record.type === 'characterData' && !!target.closest('svg[viewBox]')));
    });
    if (!sourceOnly) discoveryNeeded = true;
    // A DOM-update microtask applies masks before the next rendering step.
    // rAF is reserved for smooth number interpolation, not field discovery.
    if (!scanQueued) {
      scanQueued = true;
      queueMicrotask(scan);
    }
  }

  function restart() {
    if (!active) return;
    hasStarted = true;
    connectionConfirmed = false;
    connectionReason = null;
    resetSinceGo = new Set();
    progressFresh = false;
    progressResetSinceGo = false;
    completed = false;
    completionReason = null;
    activeEvidence = false;
    sawActiveStage = false;
    sawGoHidden = false;
    startPath = location.pathname;
    displayCache = new WeakMap();
    progressSnapshot = nativeProgress();
    progressValue = progressSnapshot;
    progressStageSnapshot = nativeTestStageActive();
    previousNativeStage = nativeStage();
    goInitiallyVisible = goIsVisible();
    if (animationFrame !== null) cancelAnimationFrame(animationFrame);
    animationFrame = null;
    phase = 'connecting';
    activeGaugeRole = 'download';
    sourceObserved = false;
    connectionSourceSnapshot = nativeReadings();
    previousSource = { ...connectionSourceSnapshot };
    chooseCenters();
    clockStart = null;
    ensureAnimation();
    paint();
    scheduleScan();
  }

  function startControl(event) {
    const path = typeof event.composedPath === 'function' ? event.composedPath() : [];
    const elements = path.filter(node => node instanceof Element).slice(0, 8);
    if (!elements.length) {
      let element = event.target instanceof Element ? event.target : event.target && event.target.parentElement;
      for (let depth = 0; element && depth < 8; depth++, element = element.parentElement) elements.push(element);
    }
    const startLabel = /^(?:go|test again|start test|again)$/i;
    for (const element of elements) {
      if (element === document.body || element === document.documentElement || element.matches('input, textarea, select, [contenteditable="true"]')) break;
      if (element.matches(startSelector)) return element;
      if ([element.getAttribute('aria-label'), element.getAttribute('title'), textOf(element)].some(label => startLabel.test(normalize(label)))) {
        return element.closest('button, a, [role="button"]') || element;
      }
    }
    return null;
  }

  function onActivate(event) {
    if (!active) return;
    // Native keyboard activation of a real button emits click as well. A canceled
    // initial pointer press or key press must never leave the waiting state.
    if (!hasStarted && event.type !== 'click') return;
    if (event.type === 'keydown' && (event.repeat || !['Enter', ' ', 'Spacebar'].includes(event.key))) return;
    if (event.type === 'pointerdown' && ((event.button !== undefined && event.button !== 0) || event.isPrimary === false)) return;
    const control = startControl(event);
    if (!control) return;
    const now = performance.now();
    // One physical interaction can dispatch pointerdown, keydown and click.
    // Coalesce them without preventing or synthesizing any native page action.
    if (lastActivation && now - lastActivation.time < activationDedupMs) return;
    lastActivation = { time: now, control };
    restart();
  }

  window.__speedtestLocalDisplayOverride = {
    restart,
    status() {
      const counts = Object.fromEntries(Object.keys(selectors).map(role => [role, 0]));
      for (const role of bindings.values()) counts[role]++;
      return { ...counts, phase, sourceObserved, mode: 'local display only', zeroHoldMs, fluctuationFraction,
        waitingForGo: !hasStarted,
        waitingForConnection: hasStarted && !connectionConfirmed && !completed,
        waitingForServer: connectionPlaceholderVisible(),
        nativeTestStageActive: nativeTestStageActive(),
        connectionConfirmed, connectionReason,
        progress: { value: progressValue, snapshot: progressSnapshot, fresh: progressFresh, resetObserved: progressResetSinceGo },
        activeGaugeRole, dial: gaugeAdapter ? gaugeAdapter.status() : null,
        completed, completionReason, activeEvidence,
        animationStarted: clockStart !== null, animating: animationFrame !== null, rampDurations: { ...rampDurations },
        centers: centers ? { ...centers } : null };
    },
    stop() {
      active = false;
      observer.disconnect();
      for (const type of ['pointerdown', 'click', 'keydown']) document.removeEventListener(type, onActivate, true);
      scanQueued = false;
      if (animationFrame !== null) cancelAnimationFrame(animationFrame);
      animationFrame = null;
      for (const element of Array.from(savedAttrs.keys())) restore(element);
      bindings.clear();
      if (gaugeAdapter) gaugeAdapter.stop();
      delete window.__speedtestLocalDisplayOverride;
    }
  };
  for (const type of ['pointerdown', 'click', 'keydown']) document.addEventListener(type, onActivate, true);
  observer.observe(document, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: observedAttributes });
  scan();
})();
