// Local presentation adapter. Native values, paths and needle transforms stay intact.
(() => {
  'use strict';

  const SVG_NS = 'http://www.w3.org/2000/svg';
  const CENTER = 143;
  const RADIUS = 141.5;
  const TICKS = [0, 5, 10, 50, 100, 250, 500, 750, 1000];
  const ANGLES = [-135, -101.25, -67.5, -33.75, 0, 33.75, 67.5, 101.25, 135];
  const NUMBER = /^(?:[+]?\d[\d,]*(?:\.\d+)?|--?|\u2013|\u2014|\u2026)$/;
  const DECIMAL = /^[+]?\d[\d,]*\.\d+$/;
  const HTML_VALUES = 'span, div, p, strong, b, output, dd, h1, h2, h3, h4, h5, h6';
  const normalize = value => String(value || '').replace(/\s+/g, ' ').trim();
  const textOf = element => normalize(element.textContent);
  const precision = value => String(Number(value.toFixed(6)));
  let nextId = 0;

  function rotationFor(value) {
    if (value <= TICKS[0]) return ANGLES[0];
    for (let index = 1; index < TICKS.length; index++) {
      if (value <= TICKS[index]) {
        const portion = (value - TICKS[index - 1]) / (TICKS[index] - TICKS[index - 1]);
        return ANGLES[index - 1] + portion * (ANGLES[index] - ANGLES[index - 1]);
      }
    }
    return ANGLES[ANGLES.length - 1];
  }

  function wedgeFor(rotation) {
    // The zero tick is southwest; clockwise travel covers 270 degrees.
    const point = degrees => {
      const radians = degrees * Math.PI / 180;
      return [CENTER + RADIUS * Math.cos(radians), CENTER + RADIUS * Math.sin(radians)]
        .map(precision).join(' ');
    };
    const start = point(135);
    const sweep = rotation + 135;
    if (sweep <= 0) return `M ${CENTER} ${CENTER} L ${start} Z`;
    return `M ${CENTER} ${CENTER} L ${start} A ${RADIUS} ${RADIUS} 0 ${sweep > 180 ? 1 : 0} 1 ${point(rotation - 90)} Z`;
  }

  function imagePhase(image) {
    const href = image.getAttribute('href') || image.getAttributeNS('http://www.w3.org/1999/xlink', 'href') || '';
    const match = href.match(/gauge[-_]gradient[-_](dl|ul|download|upload)(?:[-_.]|$)/i);
    return match ? (/^(?:ul|upload)$/i.test(match[1]) ? 'upload' : 'download') : null;
  }

  function nativeNeedle(svg) {
    for (const group of svg.querySelectorAll('g[transform]')) {
      if (group.closest('[data-tkm-owned]')) continue;
      const rotate = (group.getAttribute('transform') || '').match(/rotate\s*\(([^)]+)\)/i);
      const values = rotate && rotate[1].match(/[+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?/gi);
      if (!values || values.length < 3 || Math.abs(Number(values[1]) - CENTER) > 0.5 || Math.abs(Number(values[2]) - CENTER) > 0.5) continue;
      const path = Array.from(group.children).find(child => {
        if (child.localName !== 'path') return false;
        const commands = (child.getAttribute('d') || '').match(/[a-df-z]/gi) || [];
        return commands.join('').toUpperCase() === 'MLLLZ';
      });
      if (path) return group;
    }
    return null;
  }

  function isDial(svg) {
    const box = (svg.getAttribute('viewBox') || '').trim().split(/[\s,]+/).map(Number);
    if (box.length === 4 && box[0] === 0 && box[1] === 0 && Math.abs(box[2] - 286) < 0.5 && Math.abs(box[3] - 286) < 0.5) return true;
    const labels = new Set(Array.from(svg.querySelectorAll('text'), element => Number(textOf(element).replace(/,/g, ''))));
    return TICKS.every(value => labels.has(value));
  }

  class TkmGaugeAdapter {
    constructor(document) {
      this.document = document;
      this.view = document.defaultView;
      this.states = new Map();
      this.readouts = [];
      this.stopped = false;
    }

    style(element) {
      return this.view && this.view.getComputedStyle ? this.view.getComputedStyle(element) : null;
    }

    usable(element) {
      if (!element || !element.isConnected || element.closest('script, style, template, noscript, input, textarea, select')) return false;
      for (let node = element, depth = 0; node && depth < 10; node = node.parentElement, depth++) {
        if (node.hidden || node.getAttribute('aria-hidden') === 'true') return false;
        const style = this.style(node);
        // Numeric masks deliberately hide visibility while preserving layout.
        if (style && style.display === 'none') return false;
      }
      return true;
    }

    mark(state, element, attribute, value) {
      let saved = state.markers.get(element);
      if (!saved) state.markers.set(element, saved = new Map());
      if (!saved.has(attribute)) saved.set(attribute, element.getAttribute(attribute));
      if (element.getAttribute(attribute) !== value) element.setAttribute(attribute, value);
    }

    restoreMarker(state, element, attribute) {
      const saved = state.markers.get(element);
      if (!saved || !saved.has(attribute)) return;
      const value = saved.get(attribute);
      if (value === null) element.removeAttribute(attribute);
      else if (element.getAttribute(attribute) !== value) element.setAttribute(attribute, value);
    }

    makeState(svg, needle) {
      const state = { svg, needle, markers: new Map(), images: new Map(), parentOpacity: new Map(), lastPhase: null };
      const defs = this.document.createElementNS(SVG_NS, 'defs');
      const clip = this.document.createElementNS(SVG_NS, 'clipPath');
      const path = this.document.createElementNS(SVG_NS, 'path');
      let id;
      do { id = 'tkm-local-gauge-clip-' + (++nextId); } while (this.document.getElementById(id));
      defs.setAttribute('data-tkm-owned', 'clip');
      clip.setAttribute('id', id);
      clip.setAttribute('clipPathUnits', 'userSpaceOnUse');
      path.setAttribute('d', wedgeFor(-135));
      clip.appendChild(path);
      defs.appendChild(clip);
      svg.insertBefore(defs, svg.firstChild);
      state.defs = defs;
      state.clipPath = path;
      state.clipReference = 'url(#' + id + ')';

      const owned = needle.cloneNode(true);
      // Keep the native path's fill/gradient, without native CSS animation hooks.
      for (const element of [owned, ...owned.querySelectorAll('*')]) {
        element.removeAttribute('id');
        element.removeAttribute('class');
        element.removeAttribute('data-tkm-native-needle');
        for (const property of ['transform', 'animation', 'transition', 'visibility', 'display', 'opacity']) element.style.removeProperty(property);
        if (!element.getAttribute('style')) element.removeAttribute('style');
      }
      owned.removeAttribute('opacity');
      owned.setAttribute('data-tkm-owned', 'needle');
      owned.setAttribute('data-tkm-owned-needle', 'true');
      owned.setAttribute('transform', 'rotate(-135,143,143)');
      needle.parentNode.insertBefore(owned, needle.nextSibling);
      state.ownedNeedle = owned;
      this.mark(state, needle, 'data-tkm-native-needle', 'true');
      this.refreshImages(state);
      return state;
    }

    restoreImage(record) {
      const image = record.image;
      // Restore the exact original style when no native style update intervened.
      if (image.getAttribute('style') === record.overrideStyle) {
        if (record.originalStyle === null) image.removeAttribute('style');
        else image.setAttribute('style', record.originalStyle);
      } else if (image.style.getPropertyValue('clip-path') === record.clipReference) {
        if (record.clipValue) image.style.setProperty('clip-path', record.clipValue, record.clipPriority);
        else image.style.removeProperty('clip-path');
        if (!record.hadStyle && !image.getAttribute('style')) image.removeAttribute('style');
      }
    }

    refreshImages(state) {
      const images = Array.from(state.svg.querySelectorAll('image')).filter(image => !image.closest('[data-tkm-owned]') && imagePhase(image));
      for (const [image, record] of state.images) {
        if (images.includes(image)) continue;
        this.restoreImage(record);
        state.images.delete(image);
      }
      for (const image of images) {
        let parent = image.parentElement;
        for (let node = parent, depth = 0; node && node !== state.svg && depth < 3; node = node.parentElement, depth++) {
          if (node.hasAttribute('opacity') || node.style.getPropertyValue('opacity')) { parent = node; break; }
        }
        const existing = state.images.get(image);
        if (existing) {
          existing.parent = parent;
          if (image.style.getPropertyValue('clip-path') !== existing.clipReference || image.style.getPropertyPriority('clip-path') !== 'important') {
            // A native rerender may replace the inline style. Retain that new
            // native clip for restoration, then reapply our presentation clip.
            existing.originalStyle = image.getAttribute('style');
            existing.hadStyle = image.hasAttribute('style');
            existing.clipValue = image.style.getPropertyValue('clip-path');
            existing.clipPriority = image.style.getPropertyPriority('clip-path');
            image.style.setProperty('clip-path', state.clipReference, 'important');
            existing.clipReference = image.style.getPropertyValue('clip-path');
            existing.overrideStyle = image.getAttribute('style');
          }
          continue;
        }
        const record = {
          image, parent, originalStyle: image.getAttribute('style'), hadStyle: image.hasAttribute('style'),
          clipValue: image.style.getPropertyValue('clip-path'), clipPriority: image.style.getPropertyPriority('clip-path'),
          clipReference: state.clipReference
        };
        image.style.setProperty('clip-path', state.clipReference, 'important');
        // CSSOM may serialize url(#id) as url("#id"). Compare its canonical
        // installed value so rediscovery cannot save our own clip as native.
        record.clipReference = image.style.getPropertyValue('clip-path');
        record.overrideStyle = image.getAttribute('style');
        state.images.set(image, record);
      }
      const parents = new Set(Array.from(state.images.values(), record => record.parent));
      for (const parent of state.parentOpacity.keys()) {
        if (!parents.has(parent)) {
          this.restoreMarker(state, parent, 'data-tkm-fill-parent');
          state.parentOpacity.delete(parent);
        }
      }
      // Discovery runs after native class/style updates. Read CSS opacity once
      // without our marker; ordinary animation frames need no style writes.
      for (const parent of parents) {
        this.restoreMarker(state, parent, 'data-tkm-fill-parent');
        const style = this.style(parent);
        const opacity = style && style.opacity !== '' ? Number(style.opacity) : 1;
        state.parentOpacity.set(parent, Number.isFinite(opacity) ? opacity : 1);
      }
      this.selectPhase(state);
    }

    imageVisibility(state, record) {
      let visibility = 1;
      for (let node = record.image, depth = 0; node && depth < 12; node = node.parentElement, depth++) {
        if (node.hidden || node.getAttribute('aria-hidden') === 'true') return 0;
        const style = this.style(node);
        if (style && (style.display === 'none' || style.visibility === 'hidden' || style.visibility === 'collapse')) return 0;
        const inline = node.style.getPropertyValue('opacity');
        const attribute = node.getAttribute('opacity');
        let opacity;
        if (inline !== '') opacity = Number(inline);
        else if (attribute !== null && attribute !== '') opacity = Number(attribute);
        else if (state.parentOpacity.has(node)) opacity = state.parentOpacity.get(node);
        else opacity = style && style.opacity !== '' ? Number(style.opacity) : 1;
        if (Number.isFinite(opacity)) visibility *= Math.max(0, Math.min(1, opacity));
        if (node === this.document.body || node === this.document.documentElement) break;
      }
      return visibility;
    }

    selectPhase(state) {
      let chosen = null;
      for (const record of state.images.values()) {
        const phase = imagePhase(record.image);
        const visibility = phase ? this.imageVisibility(state, record) : 0;
        if (visibility <= 0.001) continue;
        if (!chosen || visibility > chosen.visibility || (visibility === chosen.visibility && phase === state.lastPhase)) chosen = { record, phase, visibility };
      }
      const parent = chosen && chosen.record.parent;
      for (const candidate of state.parentOpacity.keys()) {
        if (candidate === parent) this.mark(state, candidate, 'data-tkm-fill-parent', 'true');
        else this.restoreMarker(state, candidate, 'data-tkm-fill-parent');
      }
      if (chosen) state.lastPhase = chosen.phase;
      return chosen;
    }

    numericCandidates(scope, excluded) {
      const result = [];
      const blocked = element => excluded.some(other => other && (other === element || other.contains(element) || element.contains(other)));
      for (const element of scope.querySelectorAll(HTML_VALUES)) {
        if (element.namespaceURI === SVG_NS || element.querySelector('svg') || blocked(element) || !this.usable(element) || !NUMBER.test(textOf(element))) continue;
        let value = element;
        while (true) {
          const children = Array.from(value.children).filter(child => child.namespaceURI !== SVG_NS && textOf(child) === textOf(value) && NUMBER.test(textOf(child)));
          if (children.length !== 1 || blocked(children[0]) || !this.usable(children[0])) break;
          value = children[0];
        }
        if (!result.some(other => other === value || other.contains(value) || value.contains(other))) result.push(value);
      }
      return result;
    }

    hasNearbyUnit(element, scope, candidates) {
      for (let parent = element.parentElement, depth = 0; parent && depth < 3; parent = parent.parentElement, depth++) {
        if (!scope.contains(parent) && parent !== scope) break;
        const units = Array.from(parent.querySelectorAll('span, div, p, small, label')).filter(unit => unit.namespaceURI !== SVG_NS && /^Mbps$/i.test(textOf(unit)));
        if (units.some(unit => !element.contains(unit)) && candidates.filter(candidate => parent.contains(candidate)).length === 1) return true;
        if (parent === scope) break;
      }
      return false;
    }

    findReadout(svg, excluded) {
      const dial = svg.getBoundingClientRect();
      const hasGeometry = dial.width > 0 && dial.height > 0;
      for (let scope = svg.parentElement, depth = 0; scope && depth < 4; scope = scope.parentElement, depth++) {
        if (scope === this.document.body || scope === this.document.documentElement) break;
        const candidates = this.numericCandidates(scope, excluded);
        const ranked = [];
        if (hasGeometry) {
          for (const element of candidates) {
            const rect = element.getBoundingClientRect();
            if (!(rect.width > 0 && rect.height > 0)) continue;
            const x = rect.left + rect.width / 2;
            const y = rect.top + rect.height / 2;
            const dx = Math.abs(x - (dial.left + dial.width / 2));
            if (dx > dial.width * 0.28 || y < dial.top + dial.height * 0.48 || y > dial.top + dial.height * 1.08) continue;
            const unit = this.hasNearbyUnit(element, scope, candidates);
            ranked.push({ element, score: dx / dial.width + Math.abs(y - (dial.top + dial.height * 0.77)) / dial.height - (unit ? 1 : 0) });
          }
        }
        if (ranked.length) return ranked.sort((a, b) => a.score - b.score)[0].element;
        const decimalWithUnit = candidates.filter(element => DECIMAL.test(textOf(element)) && this.hasNearbyUnit(element, scope, candidates));
        if (decimalWithUnit.length === 1) return decimalWithUnit[0];
      }
      return null;
    }

    dispose(state) {
      for (const record of state.images.values()) this.restoreImage(record);
      for (const [element, attributes] of state.markers) {
        for (const attribute of attributes.keys()) this.restoreMarker(state, element, attribute);
      }
      state.ownedNeedle.remove();
      state.defs.remove();
    }

    discover(excludedElements = []) {
      if (this.stopped) return [];
      const found = new Map();
      for (const svg of this.document.querySelectorAll('svg')) {
        if (!this.usable(svg) || !isDial(svg)) continue;
        const needle = nativeNeedle(svg);
        if (needle) found.set(svg, needle);
      }
      for (const [svg, state] of this.states) {
        if (found.get(svg) !== state.needle || !state.ownedNeedle.isConnected || !state.defs.isConnected) {
          this.dispose(state);
          this.states.delete(svg);
        }
      }
      for (const [svg, needle] of found) {
        if (!this.states.has(svg)) this.states.set(svg, this.makeState(svg, needle));
        else this.refreshImages(this.states.get(svg));
      }
      this.readouts = [];
      for (const svg of this.states.keys()) {
        const readout = this.findReadout(svg, [...excludedElements, ...this.readouts]);
        if (readout) this.readouts.push(readout);
      }
      return this.readouts.slice();
    }

    phase() {
      if (this.stopped) return null;
      let selected = null;
      for (const state of this.states.values()) {
        if (!state.svg.isConnected) continue;
        const chosen = this.selectPhase(state);
        if (chosen && (!selected || chosen.visibility > selected.visibility)) selected = chosen;
      }
      return selected ? selected.phase : null;
    }

    paint(numericString) {
      if (this.stopped || !/^[+]?\d[\d,]*(?:\.\d+)?$/.test(normalize(numericString))) return;
      const value = Number(String(numericString).replace(/,/g, ''));
      if (!Number.isFinite(value)) return;
      const rotation = rotationFor(value);
      const transform = `rotate(${precision(rotation)},143,143)`;
      const wedge = wedgeFor(rotation);
      for (const state of this.states.values()) {
        if (!state.svg.isConnected) continue;
        this.selectPhase(state);
        if (state.ownedNeedle.getAttribute('transform') !== transform) state.ownedNeedle.setAttribute('transform', transform);
        if (state.clipPath.getAttribute('d') !== wedge) state.clipPath.setAttribute('d', wedge);
      }
    }

    status() {
      let needles = 0;
      let fills = 0;
      let gauges = 0;
      for (const state of this.states.values()) {
        if (!state.svg.isConnected) continue;
        gauges++;
        if (state.ownedNeedle.isConnected) needles++;
        fills += state.images.size;
      }
      return { gauges, needles, fills, readouts: this.readouts.filter(element => element.isConnected).length };
    }

    stop() {
      if (this.stopped) return;
      this.stopped = true;
      for (const state of this.states.values()) this.dispose(state);
      this.states.clear();
      this.readouts = [];
    }
  }

  globalThis.TkmGaugeAdapter = TkmGaugeAdapter;
})();
