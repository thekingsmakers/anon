LOCAL SPEEDTEST DISPLAY - CHROME EXTENSION 2.0.0

This standard Chrome extension automatically covers matching local display
fields on speedtest.net. It has no popup and does not need Tampermonkey or
PowerShell running. It remains visible in Chrome's extension manager.

ONE-TIME INSTALL IN YOUR EXISTING CHROME
1. Disable the previous Speedtest userscript in Tampermonkey, if installed.
   Also close any Chrome window controlled by the earlier PowerShell script.
   Running multiple overrides together can make them compete.
   Remove or disable version 1.0.0 of Local Speedtest Display before loading v2.
2. If using the ZIP, extract it first. Keep the extracted folder in place.
3. Open chrome://extensions in your existing Chrome window/profile.
4. Enable Developer mode.
5. Choose Load unpacked and select the Speedtest-Display-Extension folder
   containing manifest.json, content.js, and mask.css.
   Confirm that Chrome's extension card shows version 2.0.0.
6. Reload any existing Speedtest tabs or open https://www.speedtest.net/.

After installation it activates automatically on matching page loads.
No extension button or Go click is needed to activate the local display.
It does not automatically start an actual speed test.

DISPLAY DEFAULTS
Download: 419.01 Mbps
Upload: 43.38 Mbps
Idle ping: 50 ms
Download latency: 60 ms
Upload latency: 50 ms
Server name: CenturyLink
Server location: Seattle, WA

Version 2 directly matches the MUI markup supplied in the conversation: the
Receiving/Sending Time SVG icons and nearby h3 readings, plus the Idle Latency,
Download Latency, and Upload Latency SVG icons and adjacent numeric spans.
It also includes label-based discovery and nested-number support as fallbacks.
A local CSS cover displays configured text over
matched fields while leaving the site's underlying text unchanged.
Animation/phase inference depends on changes in the page's native readings.
It does not intercept or change the actual measurement stream.
When an upload completion signal cannot be identified, 4.5 seconds without
new native upload readings is used as an approximate completion signal.
Canvas graphics and unrecognized fields may remain unchanged.

TO CHANGE VALUES
Edit the configuration near the top of content.js. Then reload the extension
in chrome://extensions and refresh the Speedtest tab.

TO STOP
Disable or remove Local Speedtest Display in chrome://extensions, then refresh
all open Speedtest tabs. Disabling alone may leave code running in an already
loaded tab until that tab is refreshed or closed.

SCOPE AND LIMITS
The extension changes local text only. It does not select an actual Seattle
server, alter bandwidth or latency, intercept network traffic, or change
Ookla's stored results, result images, or share links.
The extension remains visible to browser users/administrators. These files
do not contain a mechanism to hide it or install it on other devices.
It requests only the two matching Speedtest hosts through its content-script
declaration; it has no background worker or extra extension API permissions.

VALIDATION
Manifest/file checks, JavaScript syntax, and DOM checks using the supplied MUI
markup passed. The checks cover heading/latency discovery, automatic masking,
native-reading updates, old-result-URL Go restarts, replaced headings, and cleanup.
A complete live test and final Chrome rendering remain unverified because
browser access was declined. Website updates may require selector changes.
Generated mask text can differ from copied text or accessibility output.

IF NOTHING CHANGES
Confirm version 2.0.0 is enabled in the Chrome profile running the test, confirm
that site access permits speedtest.net, then refresh that Speedtest tab.
If Chrome shows an Errors button on the extension card, inspect those errors.
An installation/loading failure prevents all content-script changes, regardless
of the selectors. A field-discovery failure affects only unmatched readouts.
The earlier PowerShell/userscript downloads are not the version 2 extension.

Chrome's official local-install instructions:
https://developer.chrome.com/docs/extensions/get-started/tutorial/hello-world#load-unpacked
