// Local display animation only. Actual network measurements and saved results are unchanged.
// Runs automatically on the two Speedtest hosts declared in manifest.json.
// No background worker, popup, network interception, or external requests.
// Disable other display overrides before enabling this extension.
// Disable/remove this extension and refresh open Speedtest tabs to stop it.

// Local presentation override only. Native page text and measured/saved results stay intact.
// No network interception, background process, or access to other devices.
(() => {
  'use strict';
  if (window.top !== window || !/^(www\.)?speedtest\.net$/i.test(location.hostname)) return;
  if (window.__speedtestLocalDisplayOverride) window.__speedtestLocalDisplayOverride.stop();

  const values = {
    download: '419.01', upload: '43.38', ping: '50', downloadLatency: '60',
    uploadLatency: '50', serverName: 'CenturyLink', serverLocation: 'Seattle, WA'
  };
  const roleAttr = 'data-st-display-role';
  const valueAttr = 'data-st-display-value';
  const selectors = {
    download: '.download-speed, .result-data-download .result-data-large, [data-testid="download-speed"]',
    upload: '.upload-speed, .result-data-upload .result-data-large, [data-testid="upload-speed"]',
    ping: '.ping-speed, .result-data-ping .result-data-value, .latency-idle .result-data-value',
    downloadLatency: '.download-latency, .latency-download .result-data-value, .result-data-download-latency .result-data-value',
    uploadLatency: '.upload-latency, .latency-upload .result-data-value, .result-data-upload-latency .result-data-value',
    gauge: '.speedometer-speed, .speedometer-value, [data-testid="speedometer-value"]',
    serverName: '.server-host .host-display, .server-host .host-name, .server-host .server-name, .server-details .server-name, .result-data-server .result-data-label',
    serverLocation: '.server-location, .server-host .host-location, .server-details .server-location, .result-data-server .result-data-value'
  };
  const startSelector = '.js-start-test, .start-button, [data-testid="start-test"]';
  const observedAttributes = ['class', 'style', 'hidden', 'aria-hidden', 'aria-valuenow', 'aria-label', 'data-state', 'data-stage', 'data-test-stage'];
  const savedAttrs = new Map();
  let bindings = new Map();
  let active = true;
  let scanQueued = false;
  let discoveryNeeded = true;
  let displayCache = new WeakMap();
  let animationFrame = null;
  let quietTimer = null;
  let phase = 'idle';
  let running = false;
  let previousStage = null;
  let runPath = location.pathname;
  let previousSource = {};
  let sourceObserved = false;
  let lastFrameTime = 0;
  const shown = { download: Number(values.download), upload: Number(values.upload) };
  let goals = { ...shown };
  const observer = new MutationObserver(scheduleScan);
  const normalize = text => String(text || '').replace(/\s+/g, ' ').trim();
  const textOf = element => normalize(element.textContent);

  function isUsable(element) {
    if (!element || !element.isConnected || element.closest('script, style, template, noscript, input, textarea, select')) return false;
    for (let parent = element, depth = 0; parent && depth < 9; parent = parent.parentElement, depth++) {
      if (parent.hidden || parent.getAttribute('aria-hidden') === 'true') return false;
      // Our CSS masks visibility, so visibility must never be used for discovery.
      if (!displayCache.has(parent)) displayCache.set(parent, getComputedStyle(parent).display);
      if (displayCache.get(parent) === 'none') return false;
    }
    return true;
  }

  function numericText(element) {
    const text = textOf(element);
    return text !== '' && /^(?:[+-]?\d[\d,]*(?:\.\d+)?|--?|\u2013|\u2014|\u2026)$/.test(text);
  }

  function numericElement(element) {
    if (!isUsable(element)) return null;
    if (numericText(element)) {
      // Descend through wrappers only when a child represents the entire number.
      // A value split across integer/decimal spans must remain one numeric wrapper.
      const same = Array.from(element.children).filter(child => textOf(child) === textOf(element) && numericText(child));
      return same.length === 1 ? numericElement(same[0]) || element : element;
    }
    for (const child of element.querySelectorAll('span, div, p, strong, b, output, dd, h1, h2, h3, h4, h5, h6')) {
      if (isUsable(child) && numericText(child)) return numericElement(child);
    }
    return null;
  }

  function numericElements(scope) {
    const result = [];
    for (const element of scope.querySelectorAll('span, div, p, strong, b, output, dd, h1, h2, h3, h4, h5, h6')) {
      if (!isUsable(element) || !numericText(element)) continue;
      const value = numericElement(element);
      if (!value || result.some(existing => existing === value || existing.contains(value) || value.contains(existing))) continue;
      result.push(value);
    }
    return result;
  }

  function addBinding(found, element, role) {
    if (!element || !isUsable(element)) return false;
    for (const existing of found.keys()) {
      if (existing === element || existing.contains(element) || element.contains(existing)) return false;
    }
    found.set(element, role);
    return true;
  }

  function hasRole(found, role) { return Array.from(found.values()).includes(role); }

  function labelElements(pattern) {
    return Array.from(document.querySelectorAll('span, div, p, label, strong, dt, h1, h2, h3, h4'))
      .filter(element => textOf(element).length < 45 && pattern.test(textOf(element)) && isUsable(element))
      .filter(element => !Array.from(element.children).some(child => pattern.test(textOf(child))));
  }

  function labelFallback(found, role, pattern) {
    if (hasRole(found, role)) return;
    for (const label of labelElements(pattern)) {
      for (let scope = label.parentElement, depth = 0; scope && depth < 4; scope = scope.parentElement, depth++) {
        const numbers = numericElements(scope);
        // A single-number metric section is safer than a whole card with many values.
        if (numbers.length === 1 && !numbers[0].contains(label)) {
          addBinding(found, numbers[0], role);
          break;
        }
        if (numbers.length > 3) break;
      }
    }
  }

  function metadata(element) {
    if (!element) return '';
    const klass = typeof element.className === 'string' ? element.className : (element.getAttribute('class') || '');
    return [klass, element.getAttribute('aria-label'), element.getAttribute('title'), element.getAttribute('data-testid')].filter(Boolean).join(' ').toLowerCase();
  }

  function latencyRole(element, scope) {
    for (let parent = element, depth = 0; parent && parent !== scope && depth < 4; parent = parent.parentElement, depth++) {
      const cue = [metadata(parent), metadata(parent.previousElementSibling), metadata(parent.nextElementSibling)].join(' ');
      if (/download/.test(cue)) return 'downloadLatency';
      if (/upload/.test(cue)) return 'uploadLatency';
      if (/idle|ping/.test(cue)) return 'ping';
    }
    return null;
  }

  function pingFallback(found) {
    if (['ping', 'downloadLatency', 'uploadLatency'].every(role => hasRole(found, role))) return;
    for (const label of labelElements(/^ping\s*(?:ms)?$/i)) {
      for (let scope = label.parentElement, depth = 0; scope && depth < 4; scope = scope.parentElement, depth++) {
        const numbers = numericElements(scope);
        if (numbers.length > 3) break;
        if (numbers.length !== 1 && numbers.length !== 3) continue;
        numbers.forEach((number, index) => {
          const role = latencyRole(number, scope) || (numbers.length === 3 ? ['ping', 'downloadLatency', 'uploadLatency'][index] : 'ping');
          if (!hasRole(found, role)) addBinding(found, number, role);
        });
        if (numbers.length === 3) break;
      }
    }
  }

  function serverTextElement(element) {
    if (!isUsable(element) || !textOf(element) || textOf(element).length > 120) return null;
    const children = Array.from(element.children).filter(child => textOf(child));
    if (children.length === 1 && textOf(children[0]) === textOf(element)) return serverTextElement(children[0]);
    // Mask only a single label, never a server panel with links or separate lines.
    if (element.querySelector('a, button, p, div, br') || children.length > 1) return null;
    return element;
  }

  function discover() {
    const found = new Map();
    // Current MUI layout supplied by the user: labeled SVG icons precede the
    // metric's heading or latency span. No generated css-* class is required.
    for (const [role, iconLabel, metricLabel] of [
      ['download', 'Receiving Time', 'download'],
      ['upload', 'Sending Time', 'upload']
    ]) {
      for (const icon of document.querySelectorAll('svg[aria-label="' + iconLabel + '"]')) {
        const metric = icon.nextElementSibling;
        const label = metric && metric.querySelector('p');
        const heading = metric && metric.querySelector('h3');
        if (label && new RegExp('^' + metricLabel + '\\s+(?:m|k|g)?bps$', 'i').test(textOf(label))) {
          addBinding(found, numericElement(heading), role);
        }
      }
    }
    for (const [role, iconLabel] of [
      ['ping', 'Idle Latency'],
      ['downloadLatency', 'Download Latency'],
      ['uploadLatency', 'Upload Latency']
    ]) {
      for (const icon of document.querySelectorAll('svg[aria-label="' + iconLabel + '"]')) {
        addBinding(found, numericElement(icon.nextElementSibling), role);
      }
    }
    for (const [role, selector] of Object.entries(selectors)) {
      for (const candidate of document.querySelectorAll(selector)) {
        addBinding(found, role.startsWith('server') ? serverTextElement(candidate) : numericElement(candidate), role);
      }
    }
    labelFallback(found, 'download', /^download\s+(?:m|k|g)?bps$/i);
    labelFallback(found, 'upload', /^upload\s+(?:m|k|g)?bps$/i);
    pingFallback(found);
    return found;
  }

  function restore(element) {
    const before = savedAttrs.get(element);
    if (!before) return;
    for (const [attribute, value] of Object.entries(before)) {
      if (value === null) element.removeAttribute(attribute); else element.setAttribute(attribute, value);
    }
    savedAttrs.delete(element);
  }

  function updateBindings(found) {
    for (const element of bindings.keys()) if (!found.has(element)) restore(element);
    bindings = found;
    for (const [element, role] of bindings) {
      if (!savedAttrs.has(element)) savedAttrs.set(element, { [roleAttr]: element.getAttribute(roleAttr), [valueAttr]: element.getAttribute(valueAttr) });
      if (element.getAttribute(roleAttr) !== role) element.setAttribute(roleAttr, role);
    }
  }

  function nativeNumber(role) {
    for (const [element, boundRole] of bindings) {
      if (boundRole !== role) continue;
      const number = Number(textOf(element).replace(/,/g, ''));
      if (numericText(element) && Number.isFinite(number)) return number;
    }
    return null;
  }

  function visibleMatch(selector) { return Array.from(document.querySelectorAll(selector)).some(isUsable); }

  function nativeStage() {
    if (/\/result\//.test(location.pathname) && (!running || (phase === 'upload' && location.pathname !== runPath))) return 'done';
    if (visibleMatch('.test-state-upload, .test-stage-upload, .speedometer.upload, .speedometer-container.upload, [data-state="upload"], [data-stage="upload"], [data-test-stage="upload"]')) return 'upload';
    if (visibleMatch('.test-state-download, .test-stage-download, .speedometer.download, .speedometer-container.download, [data-state="download"], [data-stage="download"], [data-test-stage="download"]')) return 'download';
    if (visibleMatch('.test-state-complete, .test-state-finished, [data-state="complete"], [data-state="finished"]')) return 'done';
    return null;
  }

  function finish() {
    running = false;
    phase = 'done';
    clearTimeout(quietTimer);
    quietTimer = null;
    setGoals(Number(values.download), Number(values.upload));
  }

  function updateProgress() {
    const source = { download: nativeNumber('download'), upload: nativeNumber('upload') };
    const changed = role => source[role] !== null && previousSource[role] !== undefined && source[role] !== previousSource[role];
    const downloadChanged = changed('download');
    const uploadChanged = changed('upload');
    const stage = nativeStage();
    const stageChanged = stage !== previousStage;
    previousStage = stage;
    if (stage === 'done' && (!running || sourceObserved)) { finish(); previousSource = source; return; }
    if ((stage === 'download' || stage === 'upload') && (running || phase === 'idle' || stageChanged)) {
      running = true;
      phase = stage;
    }
    if (running) {
      if (uploadChanged && source.upload > 0) phase = 'upload';
      else if (downloadChanged && source.download > 0 && phase !== 'upload') phase = 'download';
      if (downloadChanged || uploadChanged) sourceObserved = true;
      // These are local display mappings of native updates, not measured Mbps.
      const mapped = (number, target) => number > 0 ? target * (1 - Math.exp(-number / target)) : 0;
      if (phase === 'download') setGoals(mapped(source.download || 0, Number(values.download)), 0);
      else if (phase === 'upload') setGoals(Number(values.download), mapped(source.upload || 0, Number(values.upload)));
      else setGoals(0, 0);
      if (phase === 'upload' && uploadChanged) {
        clearTimeout(quietTimer);
        // Approximate completion only after native upload updates stop. This is
        // not a replacement for the site's actual test lifecycle or result.
        quietTimer = setTimeout(() => { if (active && running && phase === 'upload') finish(); }, 4500);
      }
    } else setGoals(Number(values.download), Number(values.upload));
    previousSource = source;
  }

  function paint() {
    for (const [element, role] of bindings) {
      let value = values[role];
      if (role === 'download' || role === 'upload') value = shown[role].toFixed(2);
      if (role === 'gauge') value = (phase === 'download' || phase === 'pending' ? shown.download : shown.upload).toFixed(2);
      if (element.getAttribute(valueAttr) !== value) element.setAttribute(valueAttr, value);
    }
  }

  function animate(time) {
    animationFrame = null;
    if (!active) return;
    const alpha = 1 - Math.exp(-Math.min(100, lastFrameTime ? time - lastFrameTime : 16) / 100);
    lastFrameTime = time;
    let unsettled = false;
    for (const role of ['download', 'upload']) {
      shown[role] += (goals[role] - shown[role]) * alpha;
      if (Math.abs(goals[role] - shown[role]) < 0.005) shown[role] = goals[role]; else unsettled = true;
    }
    paint();
    if (unsettled) animationFrame = requestAnimationFrame(animate);
  }

  function setGoals(download, upload) {
    goals = { download, upload };
    if (animationFrame === null && active && (Math.abs(shown.download - download) > 0.005 || Math.abs(shown.upload - upload) > 0.005)) {
      lastFrameTime = 0;
      animationFrame = requestAnimationFrame(animate);
    }
  }

  function scan() {
    scanQueued = false;
    if (!active) return;
    displayCache = new WeakMap();
    if (discoveryNeeded) {
      discoveryNeeded = false;
      updateBindings(discover());
    }
    updateProgress();
    paint();
  }

  function scheduleScan(records) {
    if (!active) return;
    const sourceOnly = records && records.length && bindings.size && Array.from(records).every(record => {
      if (record.type === 'attributes') return false;
      const target = record.target.nodeType === 1 ? record.target : record.target.parentElement;
      return target && Array.from(bindings.keys()).some(element => element === target || element.contains(target));
    });
    if (!sourceOnly) discoveryNeeded = true;
    // A DOM-update microtask applies masks before the next rendering step.
    // rAF is reserved for smooth number interpolation, not field discovery.
    if (!scanQueued) {
      scanQueued = true;
      queueMicrotask(scan);
    }
  }

  function restart() {
    if (!active) return;
    clearTimeout(quietTimer);
    quietTimer = null;
    running = true;
    phase = 'pending';
    runPath = location.pathname;
    sourceObserved = false;
    previousSource = {};
    shown.download = shown.upload = 0;
    setGoals(0, 0);
    paint();
    scheduleScan();
  }

  function onClick(event) {
    const target = event.target instanceof Element ? event.target : event.target && event.target.parentElement;
    if (!target) return;
    const knownControl = target.closest(startSelector);
    const labelledControl = target.closest('a, button, [role="button"]');
    const exactStartLabel = labelledControl && /^(?:go|test again|start test|again)$/i.test(textOf(labelledControl));
    if (knownControl || exactStartLabel) restart();
  }

  window.__speedtestLocalDisplayOverride = {
    restart,
    status() {
      const counts = Object.fromEntries(Object.keys(selectors).map(role => [role, 0]));
      for (const role of bindings.values()) counts[role]++;
      return { ...counts, phase, sourceObserved, mode: 'local display only' };
    },
    stop() {
      active = false;
      observer.disconnect();
      document.removeEventListener('click', onClick, true);
      scanQueued = false;
      if (animationFrame !== null) cancelAnimationFrame(animationFrame);
      clearTimeout(quietTimer);
      for (const element of Array.from(savedAttrs.keys())) restore(element);
      bindings.clear();
      delete window.__speedtestLocalDisplayOverride;
    }
  };
  document.addEventListener('click', onClick, true);
  observer.observe(document, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: observedAttributes });
  scan();
})();
